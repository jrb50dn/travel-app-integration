const inputData = {
  travefyTrip: JSON.stringify(require("./travefy.json")),
  libraryEvents: JSON.stringify(require("./travefy_event_data.json")),
};

const replaceContentAfterLastUl = (description, newContent) => {
    if (!description) return null; // Early return if no description
  
    // Match everything after the last </ul> tag
    return description.replace(/<\/ul>(?![\s\S]*<\/ul>)[\s\S]*/, `</ul>${newContent}`);
  };

const replaceDescriptionsWithLibraryDescriptions = (
  initialData,
  libraryEvents
) => {
  if (!initialData || !libraryEvents) return initialData; // Return initialData if libraryEvents are missing

  initialData.TripDays.forEach((tripDay) => {
    tripDay.TripEvents.forEach((event) => {
      // Find the matching event in libraryEvents by SegmentIdentifier
      const matchingEvent = libraryEvents.find(
        (e) => e.SegmentIdentifier === event.PartnerIdentifier
      );
      if (matchingEvent) {
        event.Description = replaceContentAfterLastUl(
          event.Description,
          matchingEvent.Description
        );
      }
    });
  });

  return initialData;
};

const generateEnhancedItinerary = async () => {
  // Fetch input data from Zapier
  const travefyTrip = JSON.parse(inputData.travefyTrip);
  const libraryEvents = JSON.parse(inputData.libraryEvents);

  // Map enhanced descriptions if available
  const enhancedItinerary = travefyTrip;

  // Replace descriptions with library event descriptions
  const enhancedItineraryWithLibraryItems =
    replaceDescriptionsWithLibraryDescriptions(
      enhancedItinerary,
      libraryEvents
    );

  // Return the final enhanced itinerary
  return JSON.stringify(enhancedItineraryWithLibraryItems);
};

// Execute and return the result
return (output = {
  travefyTrip: await generateEnhancedItinerary(),
});
